#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
    Actor(int imageId, double startX, double startY, int startDirection, double size, int depth,
            bool alive, double horizontalSpeed, double verticalSpeed, int health, bool collisionAvoidance, StudentWorld* world);
    virtual void doSomething() = 0;
    double getVerticalSpeed();
    void setVerticalSpeed(double v);
    double getHorizontalSpeed();
    void setHorizontalSpeed(double h);
    bool movement();
    bool getAlive();
    void setAlive(bool alive);
    int getHealth();
    void damage(int damage);
    bool getAvoid();
    virtual bool spray();
    StudentWorld* getWorld() ;
private:
    bool m_alive;
    int m_health;
    bool m_avoid;
    double m_horizontalSpeed;
    double m_verticalSpeed;
    StudentWorld* m_world;
    virtual void sound();
};

class GhostRacer : public Actor
{
public:
    GhostRacer(StudentWorld* world);
    virtual void doSomething();
    void setWater(int holyWater);
    int getWater();
    void heal();
private:
    virtual void sound();
    int m_holyWaterSpray;
};


class Agents : public Actor
{
public:
    Agents(int imageID, double x, double y, int direction, double size, double verticalSpeed, int health, StudentWorld* world);
    virtual void doSomething();
    void setMovementPlan(int distance);
private:
    virtual void act() = 0;
    virtual bool isNearby() = 0;
    virtual void movementPlan();
    int m_movementPlan;
};

class HumanPedestrian : public Agents
{
public:
    HumanPedestrian(double x, double y, StudentWorld* world);
    virtual bool spray();
private:
    virtual void act();
    virtual bool isNearby();
};

class ZombiePedestrian : public Agents
{
public:
    ZombiePedestrian(double x, double y, StudentWorld* world);
    virtual bool spray();
private:
    virtual void act();
    virtual bool isNearby();
    virtual void sound();
    int m_ticks;
};

class ZombieCab : public Agents
{
public:
    ZombieCab(double x, double y, int verticalSpeed, int lane, StudentWorld* world);
    virtual bool spray();
private:
    virtual void act();
    virtual void movementPlan();
    virtual bool isNearby();
    virtual void sound();
    int m_lane;
    bool damagedGhostRacer;
};


class HolyWaterProjectile : public Actor
{
public:
    HolyWaterProjectile(double x, double y, int direction, StudentWorld* world);
    virtual void doSomething();
private:
    int m_distance;
};


class BorderLine : public Actor
{
public:
    BorderLine(int imageID, double x, double y, StudentWorld* world);
    virtual void doSomething();
};

class Objects : public Actor
{
public:
    Objects(int imageID, int soundID, double startX, double startY, int direction, double size, int addScore, StudentWorld* world);
    virtual void doSomething();
    virtual bool spray();
private:
    virtual bool isSprayed();
    int m_addScore;
    int m_sound;
    virtual void overlap() = 0;
    virtual bool doesRotate();
    virtual bool disappear();
};

class HolyWaterGoodie : public Objects
{
public:
    HolyWaterGoodie(double x, double y, StudentWorld* world);
private:
    virtual void overlap();
    virtual bool isSprayed();
};

class SoulGoodie : public Objects
{
public:
    SoulGoodie(double x, double y, StudentWorld* world);
private:
    virtual void overlap();
    virtual bool doesRotate();
};

class OilSlick : public Objects
{
public:
    OilSlick(double x, double y, int size, StudentWorld* world);
private:
    virtual void overlap();
    virtual bool disappear();
};

class HealingGoodie : public Objects
{
public:
    HealingGoodie(double x, double y, StudentWorld* world);
private:
    virtual void overlap();
    virtual bool isSprayed();
};

#endif // ACTOR_H_
