#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <array>
#include <random>
#include <iterator>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

//studentworld constructor
StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath), m_gr(nullptr), last_y(0), souls(0), bonus(5000)
{}

//initialize world
int StudentWorld::init()
{
    //initialize GhostRacer, borderlines, and variables for current level
    m_gr = new GhostRacer(this);
    m_actorlist.push_front(m_gr);
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;

    souls = getLevel() * 2 + 5;
    bonus = 5000;
    
    //add yellow lines
    int n = VIEW_HEIGHT / SPRITE_HEIGHT;
    for (int i = 0; i < n; i++)
    {
        m_actorlist.push_front(new BorderLine(IID_YELLOW_BORDER_LINE, LEFT_EDGE, i * SPRITE_HEIGHT, this));
        m_actorlist.push_front(new BorderLine(IID_YELLOW_BORDER_LINE, RIGHT_EDGE, i * SPRITE_HEIGHT, this));
    }

    //add white lines
    int m = VIEW_HEIGHT / (4 * SPRITE_HEIGHT);
    for (int i = 0; i < m; i++)
    {
        m_actorlist.push_back(new BorderLine(IID_WHITE_BORDER_LINE, RIGHT_EDGE - ROAD_WIDTH / 3, i * (4 * SPRITE_HEIGHT), this));
        m_actorlist.push_back(new BorderLine(IID_WHITE_BORDER_LINE, LEFT_EDGE + ROAD_WIDTH / 3, i * (4 * SPRITE_HEIGHT), this));
        last_y = m_actorlist.back()->getY();
    }

    return GWSTATUS_CONTINUE_GAME;
}

//give each object opportunity to dosomething
int StudentWorld::move()
{
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;

    //update bonus
    if (bonus > 0)
        bonus--;
    
    //iterate through actor list
    list<Actor*>::iterator it;
    for (it = m_actorlist.begin(); it != m_actorlist.end(); it++)
    {
        //if actor is alive
        if ((*it)->getAlive() == true)
        {
            //let it do something
            (*it)->doSomething();
            //if GhostRacer is dead
            if (!getRacer()->getAlive())
            {
                decLives();
                return GWSTATUS_PLAYER_DIED;
            }
            //if number of souls has been reached
            if (souls == 0)
            {
                increaseScore(bonus);
                playSound(SOUND_FINISHED_LEVEL);
                return GWSTATUS_FINISHED_LEVEL;
            }
        }
    }

    //iterate through list of actors
    for (it = m_actorlist.begin(); it != m_actorlist.end(); )
    {
        //if actor is dead, delete it
        if (!(*it)->getAlive())
        {
            Actor* temp = *it;
            it = m_actorlist.erase(it);
            delete temp;
        }
        else
            it++;
    }
    
    //adding actors
    //yellow borderlines
    int new_border_y = VIEW_HEIGHT - SPRITE_HEIGHT;
    last_y = m_actorlist.back()->getY();
    int delta_y = new_border_y - last_y;
    if (delta_y >= SPRITE_HEIGHT)
    {
        m_actorlist.push_front(new BorderLine(IID_YELLOW_BORDER_LINE, LEFT_EDGE, new_border_y, this)); // left
        m_actorlist.push_front(new BorderLine(IID_YELLOW_BORDER_LINE, RIGHT_EDGE, new_border_y, this)); // right
    }
    //white borderlines
    if (delta_y >= 4 * SPRITE_HEIGHT)
    {
        m_actorlist.push_back(new BorderLine(IID_WHITE_BORDER_LINE, LEFT_EDGE + ROAD_WIDTH / 3, new_border_y, this)); // left
        m_actorlist.push_back(new BorderLine(IID_WHITE_BORDER_LINE, RIGHT_EDGE - ROAD_WIDTH / 3, new_border_y, this)); // right
        last_y = new_border_y;
    }

    //zombie cabs
    int zombieCab = max(100 - getLevel() * 10, 20);
    int chanceZombieCab = randInt(0, zombieCab - 1);
    if (chanceZombieCab == 0)
    {
        //check all the lanes to pick one
        int lanes[3] = { false, false , false };
        for (int i = 0; i < 3; )
        {
            int curr_lane = randInt(-1, 1);
            if (!lanes[curr_lane + 1])
            {
                lanes[curr_lane + 1] = true;
                //get closest to GhostRacer from top and from bottom
                Actor* a = getClosest(0, curr_lane, true);
                Actor* b = getClosest(VIEW_HEIGHT, curr_lane, false);
                //if lane is good, add in appropriate position
                if (a == nullptr || a->getY() > VIEW_HEIGHT / 3)
                {
                    m_actorlist.push_front(new ZombieCab(ROAD_CENTER + (curr_lane * ROAD_WIDTH / 3), SPRITE_HEIGHT / 2, getRacer()->getVerticalSpeed() + randInt(2, 4), curr_lane, this));
                    break;
                }
                if (b == nullptr || b->getY() < VIEW_HEIGHT * 2 / 3)
                {
                    m_actorlist.push_front(new ZombieCab(ROAD_CENTER + (curr_lane * ROAD_WIDTH / 3), VIEW_HEIGHT - SPRITE_HEIGHT / 2, getRacer()->getVerticalSpeed() - randInt(2, 4), curr_lane, this));
                    break;
                }
                i++;
            }
        }
    }
    
    //soul goodie
    int chanceSoulGoodie = randInt(0, 99);
    if (chanceSoulGoodie == 0)
    {
        m_actorlist.push_front(new SoulGoodie(randInt(LEFT_EDGE, RIGHT_EDGE), VIEW_HEIGHT, this));
    }

    //oil slick
    int chanceOilSlick = randInt(0, max(150 - getLevel(), 20) - 1);
    if (chanceOilSlick == 0)
    {
        m_actorlist.push_front(new OilSlick(randInt(LEFT_EDGE, RIGHT_EDGE), VIEW_HEIGHT, randInt(2, 5), this));
    }
    
    //human pedestrian
    int chanceHumanPed = randInt(0, max(200 - getLevel() * 10, 30) - 1);
    if (chanceHumanPed == 0)
    {
        m_actorlist.push_front(new HumanPedestrian(randInt(0, VIEW_WIDTH), VIEW_HEIGHT, this));
    }

    //zombie pedestrian
    int chanceZombiePed = randInt(0, max(100 - getLevel() * 10, 20) - 1);
    if (chanceZombiePed == 0)
    {
        m_actorlist.push_front(new ZombiePedestrian(randInt(0, VIEW_WIDTH), VIEW_HEIGHT, this));
    }

    //holy water goodie
    int chanceHolyWater = randInt(0, 99 + 10 * getLevel());
    if (chanceHolyWater == 0)
    {
        m_actorlist.push_front(new HolyWaterGoodie(randInt(LEFT_EDGE, RIGHT_EDGE), VIEW_HEIGHT, this));
    }

    //set game text
    ostringstream ss;
    ss << "Score: " << setw(4) << setfill('0') << internal << getScore()
       << "  Lvl: " << getLevel()
       << "  Souls2Save: " << souls
       << "  Lives: " << getLives()
       << "  Health: " << getRacer()->getHealth()
       << "  Sprays: " << getRacer()->getWater()
       << "  Bonus: " << bonus;
    
    setGameStatText(ss.str());

    return GWSTATUS_CONTINUE_GAME;
}

//delete all dynamically allocated actors
void StudentWorld::cleanUp()
{
    list<Actor*>::iterator it;
    for (it = m_actorlist.begin(); it != m_actorlist.end(); )
    {
        Actor* temp = *it;
        it = m_actorlist.erase(it);
        delete temp;
    }
}

//clean up world
StudentWorld::~StudentWorld()
{
    cleanUp();
}

//add soul by decrementing souls left to save
void StudentWorld::addSoul()
{
    souls--;
}

//check that actor was sprayed
bool StudentWorld::hit(Actor* a)
{
    //iterate through actors
    list<Actor*>::iterator it;
    for (it = m_actorlist.begin(); it != m_actorlist.end(); it++)
    {
        //if hit by spray and is sprayable object
        if (a != *it && overlaps(a, *it) && sprayActor(*it))
            return true;
    }
    return false;
}

//determine closest actor in given lane to certain position above or below
Actor* StudentWorld::getClosest(double position, int lane, bool isAbove)
{
    list<Actor*>::iterator it = m_actorlist.begin();
    //check above
    if (isAbove == true)
    {
        Actor* temp = nullptr;
        //iterate again to check that position and lane are correct
        for (list<Actor*>::iterator it2 = m_actorlist.begin(); it2 != m_actorlist.end(); it2++)
        {
            if ((*it2)->getAvoid() && (*it2)->getY() > position && (*it2)->getX() >= ROAD_CENTER + (lane * ROAD_WIDTH / 3) - (ROAD_WIDTH / 6) && (*it2)->getX() < ROAD_CENTER + (lane * ROAD_WIDTH / 3) + (ROAD_WIDTH / 6))
            {
                temp = *it2;
                break;
            }
        }
        //iterate again to find closest
        for (; it != m_actorlist.end() && temp != nullptr; it++)
        {
            if ((*it)->getAvoid() && (*it)->getY() > position && (*it)->getY() < temp->getY() && (*it)->getX() >= ROAD_CENTER + (lane * ROAD_WIDTH / 3) - (ROAD_WIDTH / 6) && (*it)->getX() < ROAD_CENTER + (lane * ROAD_WIDTH / 3) + (ROAD_WIDTH / 6))
                temp = *it;
        }
        return temp;
    }
    //check below
    else
    {
        Actor* temp = nullptr;
        //iterate again to check that position and lane are correct
        for (list<Actor*>::iterator it2 = m_actorlist.begin(); it2 != m_actorlist.end(); it2++)
        {
            if ((*it2)->getAvoid() && (*it2)->getY() < position && (*it2)->getX() >= ROAD_CENTER + (lane * ROAD_WIDTH / 3) - (ROAD_WIDTH / 6) && (*it2)->getX() < ROAD_CENTER + (lane * ROAD_WIDTH / 3) + (ROAD_WIDTH / 6))
            {
                temp = *it2;
                break;
            }
        }
        //iterate again to find closest
        for (; it != m_actorlist.end() && temp != nullptr; it++)
        {
            if ((*it)->getAvoid() && (*it)->getY() < position && (*it)->getY() > temp->getY() && (*it)->getX() >= ROAD_CENTER + (lane * ROAD_WIDTH / 3) - (ROAD_WIDTH / 6) && (*it)->getX() < ROAD_CENTER + (lane * ROAD_WIDTH / 3) + (ROAD_WIDTH / 6))
                temp = *it;
        }
        return temp;
    }
}

//add actor to actor list
void StudentWorld::addActor(Actor* a)
{
    m_actorlist.push_front(a);
}

//check if actor a overlaps with actor b
bool StudentWorld::overlaps(Actor* a, Actor* b)
{
    double delta_x = abs(a->getX() - b->getX());
    double delta_y = abs(a->getY() - b->getY());
    double radius_sum = a->getRadius() + b->getRadius();
    if (delta_x < radius_sum * 0.25 && delta_y < radius_sum * 0.6)
    {
        return true;
    }
    return false;
}

//get the GhostRacer
GhostRacer* StudentWorld::getRacer()
{
    return m_gr;
}

//check if actor can be sprayed
bool StudentWorld::sprayActor(Actor* a)
{
    return a->spray();
}

