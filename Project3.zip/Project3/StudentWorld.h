#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>
#include <list>
#include "Actor.h"

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class Actor;
class GhostRacer;

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    ~StudentWorld();
    void addActor(Actor* a);
    bool overlaps(Actor* a, Actor* b);
    GhostRacer* getRacer();
    void addSoul();
    bool hit(Actor* a);
    bool sprayActor(Actor* a);
    Actor* getClosest(double position, int lane, bool isAbove);
private:
    std::list<Actor*> m_actorlist;
    GhostRacer* m_gr;
    double last_y;
    int souls;
    int bonus;
};

#endif // STUDENTWORLD_H_
