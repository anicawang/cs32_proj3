#include "Actor.h"
#include "StudentWorld.h"
#include <cmath>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

//actor constructor
Actor::Actor(int imageID, double startX, double startY, int startDirection, double size, int depth,
            bool alive, double horizontalSpeed, double verticalSpeed, int health, bool collisionAvoidance, StudentWorld* world)
    : GraphObject(imageID, startX, startY, startDirection, size, depth), m_alive(alive), m_horizontalSpeed(horizontalSpeed), m_verticalSpeed(verticalSpeed), m_health(health), m_avoid(collisionAvoidance), m_world(world)
{}

//return alive status
bool Actor::getAlive()
{
    return m_alive;
}

//set alive status
void Actor::setAlive(bool alive)
{
    m_alive = alive;
}

//return health
int Actor::getHealth()
{
    return m_health;
}

//change health level
void Actor::damage(int damage)
{
    m_health -= damage;
    //if dead
    if (m_health <= 0)
    {
        setAlive(false);
        sound();
    }
}

//moves actor
bool Actor::movement()
{
    double vert_speed = getVerticalSpeed() - getWorld()->getRacer()->getVerticalSpeed();
    double horiz_speed = getHorizontalSpeed();
    double new_y = getY() + vert_speed;
    double new_x = getX() + horiz_speed;
    moveTo(new_x, new_y);
    //if out of bounds
    if (new_x < 0 || new_y < 0 || new_x > VIEW_WIDTH || new_y > VIEW_HEIGHT)
    {
        setAlive(false);
        return true;
    }
    return false;
}

//get y speed
double Actor::getVerticalSpeed()
{
    return m_verticalSpeed;
}

//set y speed
void Actor::setVerticalSpeed(double v)
{
    m_verticalSpeed = v;
}

//get x speed
double Actor::getHorizontalSpeed()
{
    return m_horizontalSpeed;
}

//set x speed
void Actor::setHorizontalSpeed(double h)
{
    m_horizontalSpeed = h;
}

//get avoidance
bool Actor::getAvoid()
{
    return m_avoid;
}

//play sound
void Actor::sound()
{}

//return spray or not
bool Actor::spray()
{
    return false;
}

//return world
StudentWorld* Actor::getWorld()
{
    return m_world;
}

//borderline constructor
BorderLine::BorderLine(int imageID, double x, double y, StudentWorld* world)
    :Actor(imageID, x, y, 0, 2.0, 2, true, 0, -4, 0, false, world)
{}

//borderline dosomething
void BorderLine::doSomething()
{
    //move
    if (movement())
    {
        return;
    }
}

//ghostracer constructor
GhostRacer::GhostRacer(StudentWorld* world)
    :Actor(IID_GHOST_RACER, 128, 32, 90, 4.0, 0, true, 0, 0, 100, true, world), m_holyWaterSpray(10)
{}

//ghostracer dosomething
void GhostRacer::doSomething()
{
    //check alive
    if (getHealth() <= 0)
    {
        return;
    }
    int LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    int RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
    //if it hits the right edge of the road
    if (getX() >= RIGHT_EDGE)
    {
        if (getDirection() < 90)
        {
            damage(10);
        }
        setDirection(98);
        getWorld()->playSound(SOUND_VEHICLE_CRASH);
    }
    //if it hits the left edge of the road
    else if (getX() <= LEFT_EDGE)
    {
        if (getDirection() > 90)
        {
            damage(10);
        }
        setDirection(82);
        getWorld()->playSound(SOUND_VEHICLE_CRASH);
    }
    //process user input
    int ch;
    if (getWorld()->getKey(ch))
    {
        switch (ch)
        {
        case KEY_PRESS_SPACE:
            if (m_holyWaterSpray >= 1)
            {
                double posX = getX();
                double posY = getY();
                getPositionInThisDirection(getDirection(), SPRITE_HEIGHT/2, posX, posY);
                getWorld()->addActor(new HolyWaterProjectile(posX, posY, getDirection(), getWorld()));
                getWorld()->playSound(SOUND_PLAYER_SPRAY);
                m_holyWaterSpray--;
            }
            break;
        case KEY_PRESS_LEFT:
            if (getDirection() < 114)
            {
                setDirection(getDirection() + 8);
            }
            break;
        case KEY_PRESS_RIGHT:
            if (getDirection() > 66)
            {
                setDirection(getDirection() - 8);
            }
            break;
        case KEY_PRESS_UP:
            if (getVerticalSpeed() < 5)
            {
                setVerticalSpeed(getVerticalSpeed() + 1);
            }
            break;
        case KEY_PRESS_DOWN:
            if (getVerticalSpeed() > -1)
            {
                setVerticalSpeed(getVerticalSpeed() - 1);
            }
            break;
        }
    }
    //moves ghostracer in current direction
    double pi = 2 * asin(1.0);
    double max_shift_per_tick = 4.0;
    int direction = getDirection();
    double delta_x = cos(direction * pi / 180) * max_shift_per_tick;
    double cur_x = getX();
    double cur_y = getY();
    moveTo(cur_x + delta_x, cur_y);
}

//sound when ghostracer dies
void GhostRacer::sound()
{
    getWorld()->playSound(SOUND_PLAYER_DIE);
}

//increase health
void GhostRacer::heal()
{
    if (getHealth() + 10 <= 100)
    {
        damage(-10);
    }
}

//change water level
void GhostRacer::setWater(int holyWater)
{
    m_holyWaterSpray += holyWater;
}

//get water level
int GhostRacer::getWater()
{
    return m_holyWaterSpray;
}

//agent constructor
Agents::Agents(int imageID, double x, double y, int direction, double size, double verticalSpeed, int health, StudentWorld* world)
    :Actor(imageID, x, y, direction, size, 0, true, 0, verticalSpeed, health, true, world), m_movementPlan(0)
{}

//setting movement plan
void Agents::movementPlan()
{
    int sign = randInt(1, 2);
    if (sign == 2)
        sign = -1;
    setHorizontalSpeed(sign * randInt(1, 3));
    if (getHorizontalSpeed() < 0)
        setDirection(180);
    else
        setDirection(0);
}

//agent do something
void Agents::doSomething()
{
    //check alive
    if (!getAlive())
        return;
    //if overlap with ghostracer
    if (getWorld()->overlaps(getWorld()->getRacer(), this))
        act();
    //if GhostRacer nearby
    if (isNearby())
        return;
    //change movement plan
    m_movementPlan--;
    if (m_movementPlan > 0)
        return;
    setMovementPlan(randInt(4, 32));
    movementPlan();
}

//set movement plan
void Agents::setMovementPlan(int distance)
{
    m_movementPlan = distance;
}

//humanpedestrian constructor
HumanPedestrian::HumanPedestrian(double x, double y, StudentWorld* world)
    :Agents(IID_HUMAN_PED, x, y, 0, 2.0, -4, 2, world)
{}

//when humanpedestrian collides with GhostRacer
void HumanPedestrian::act()
{
    getWorld()->getRacer()->setAlive(false);
    return;
}

//if GhostRacer is nearby
bool HumanPedestrian::isNearby()
{
    return movement();
}

//when hit by holy water projectile
bool HumanPedestrian::spray()
{
    setHorizontalSpeed(getHorizontalSpeed() * -1);
    if (getDirection() == 0)
        setDirection(180);
    else
        setDirection(0);
    return true;
}

//sombie pedestrian constructor
ZombiePedestrian::ZombiePedestrian(double x, double y, StudentWorld* world)
    :Agents(IID_ZOMBIE_PED, x, y, 0, 3.0, -4, 2, world), m_ticks(0)
{}

//when hit by GhostRacer
void ZombiePedestrian::act()
{
    getWorld()->getRacer()->damage(5);
    damage(2);
    return;
}

//when GhostRacer is nearby
bool ZombiePedestrian::isNearby()
{
    //check coordinates
    if (abs(getWorld()->getRacer()->getX() - getX()) <= 30.0 && abs(getWorld()->getRacer()->getX() - getX()) >= 0.0 && getWorld()->getRacer()->getY() < getY())
    {
        //make necessary adjustments
        setDirection(270);
        if (getWorld()->getRacer()->getX() > getX())
            setHorizontalSpeed(1);
        else if (getWorld()->getRacer()->getX() < getX())
            setHorizontalSpeed(-1);
        else
            setHorizontalSpeed(0);
        //change movement plan
        m_ticks--;
        if (m_ticks <= 0)
        {
            getWorld()->playSound(SOUND_ZOMBIE_ATTACK);
            m_ticks = 20;
        }
    }
    return movement();
}

//when hit by holy water projectile
bool ZombiePedestrian::spray()
{
    getWorld()->playSound(SOUND_PED_HURT);
    damage(1);
    return true;
}

//plays sound when damaged or killed
void ZombiePedestrian::sound()
{
    if (!getWorld()->overlaps(getWorld()->getRacer(), this))
    {
        int chanceOfHealing = randInt(1, 5);
        if (chanceOfHealing == 1)
            getWorld()->addActor(new HealingGoodie(getX(), getY(), getWorld()));
    }
    getWorld()->increaseScore(150);
    getWorld()->playSound(SOUND_PED_DIE);
}

//holywaterprojectile constructor
HolyWaterProjectile::HolyWaterProjectile(double x, double y, int direction, StudentWorld* world)
    :Actor(IID_HOLY_WATER_PROJECTILE, x, y, direction, 1.0, 1, true, 0, 0, 0, false, world), m_distance(0)
{}

//holywaterprojectile dosomething
void HolyWaterProjectile::doSomething()
{
    //check alive
    if (!getAlive())
        return;
    //if it hit an object
    if (getWorld()->hit(this))
    {
        damage(1);
        setAlive(false);
    }
    //keep moving until it goes 160 pixels or off screen
    moveForward(SPRITE_HEIGHT);
    m_distance += SPRITE_HEIGHT;
    if (getX() < 0 || getY() < 0 || getX() > VIEW_WIDTH || getY() > VIEW_HEIGHT)
    {
        setAlive(false);
        return;
    }
    if (m_distance >= 160)
    {
        setAlive(false);
        return;
    }
}

//zombiecab constructor
ZombieCab::ZombieCab(double x, double y, int verticalSpeed, int lane, StudentWorld* world)
    :Agents(IID_ZOMBIE_CAB, x, y, 90, 4.0, verticalSpeed, 3, world), m_lane(lane), damagedGhostRacer(false)
{}

//when it collides with GhostRacer
void ZombieCab::act()
{
    //check if it has damaged already
    if (!damagedGhostRacer)
    {
        //make necessary adjustments and play appropriate sound
        getWorld()->playSound(SOUND_VEHICLE_CRASH);
        getWorld()->getRacer()->damage(20);
        if (getX() <= getWorld()->getRacer()->getX())
        {
            setHorizontalSpeed(-5);
            setDirection(120 + randInt(0, 19));
        }
        else
        {
            setHorizontalSpeed(5);
            setDirection(60 - randInt(0, 19));
        }
        //set damage
        damagedGhostRacer = true;
    }
}

//when near GhostRacer
bool ZombieCab::isNearby()
{
    //move
    if (movement())
        return true;
    //check speed in relation to GhostRacer
    if (getVerticalSpeed() > getWorld()->getRacer()->getVerticalSpeed() && getWorld()->getClosest(getY(), m_lane, true) != nullptr)
    {
        double a = abs(getWorld()->getClosest(getY(), m_lane, true)->getY() - getY());
        if (a < 96 && a > 0)
        {
            //change speed if warranted
            setVerticalSpeed(getVerticalSpeed() - 0.5);
            return true;
        }
    }
    //check speed in relation to GhostRacer
    else if (getVerticalSpeed() <= getWorld()->getRacer()->getVerticalSpeed() && getWorld()->getClosest(getY(), m_lane, false) != nullptr)
    {
        Actor* temp = getWorld()->getClosest(getY(), m_lane, false);
        double b = abs(getY() - temp->getY());
        if (temp != getWorld()->getRacer() && b < 96 && b > 0)
        {
            //change speed if warranted
            setVerticalSpeed(getVerticalSpeed() + 0.5);
            return true;
        }
    }
    return false;
}

//set initial speed for ZombieCab
void ZombieCab::movementPlan()
{
    setVerticalSpeed(getVerticalSpeed() + randInt(-2, 2));
}

//play appropriate sound when dead
void ZombieCab::sound()
{
    getWorld()->playSound(SOUND_VEHICLE_DIE);
    if (randInt(1, 5) == 1)
        getWorld()->addActor(new OilSlick(getX(), getY(), randInt(2, 5), getWorld()));
    getWorld()->increaseScore(200);
    return;
}

//when ZombieCab is hit by holy water projectile
bool ZombieCab::spray()
{
    getWorld()->playSound(SOUND_VEHICLE_HURT);
    damage(1);
    return true;
}

//objects constructor
Objects::Objects(int imageID, int soundID, double startX, double startY, int direction, double size, int addScore, StudentWorld* world)
:Actor(imageID, startX, startY, direction, size, 2, true, 0, -4, 1, false, world), m_addScore(addScore), m_sound(soundID)
{}

//objects doSomething
void Objects::doSomething()
{
    //move
    if (movement())
        return;
    //if overlap with GhostRacer and is supposed to disappear after doing so
    if (getWorld()->overlaps(getWorld()->getRacer(), this))
    {
        if (disappear() == true)
        {
            setAlive(false);
        }
        //play sound and change score
        overlap();
        getWorld()->playSound(m_sound);
        getWorld()->increaseScore(m_addScore);
    }
    //rotate object if warranted
    if (doesRotate())
        setDirection(getDirection() - 10);
}

//does the object rotate
bool Objects::doesRotate()
{
    return false;
}

//is object supposed to disappear
bool Objects::disappear()
{
    return true;
}

//when object is sprayed
bool Objects::spray()
{
    if (isSprayed())
    {
        setAlive(false);
        return true;
    }
    return false;
}

//is object sprayable
bool Objects::isSprayed()
{
    return false;
}

//holywatergoodie constructor
HolyWaterGoodie::HolyWaterGoodie(double x, double y, StudentWorld* world)
    :Objects(IID_HOLY_WATER_GOODIE, SOUND_GOT_GOODIE, x, y, 90, 2.0, 50, world)
{}

//when collected by GhostRacer
void HolyWaterGoodie::overlap()
{
    getWorld()->getRacer()->setWater(10);
}

//is holywatergoodie affected by water spray
bool HolyWaterGoodie::isSprayed()
{
    return true;
}

//oilslick constructor
OilSlick::OilSlick(double x, double y, int size, StudentWorld* world)
    :Objects(IID_OIL_SLICK, SOUND_OIL_SLICK, x, y, 0, size, 0, world)
{}

//when overlap with GhostRacer
void OilSlick::overlap()
{
    //change direction of GhostRacer
    int changeDirection = randInt(5, 20);
    int dir = randInt(1, 2);
    if (dir == 2)
        dir = -1;
    changeDirection *= dir;
    if (getWorld()->getRacer()->getDirection() + changeDirection >= 60 || getWorld()->getRacer()->getDirection() + changeDirection <= 120)
        getWorld()->getRacer()->setDirection(getWorld()->getRacer()->getDirection() + changeDirection);
    else if (getWorld()->getRacer()->getDirection() + changeDirection < 60)
        getWorld()->getRacer()->setDirection(60);
    else if (getWorld()->getRacer()->getDirection() + changeDirection > 120)
        getWorld()->getRacer()->setDirection(120);
}

//does oil disappear after colliding with GhostRacer
bool OilSlick::disappear()
{
    return false;
}

//healinggoodie constructor
HealingGoodie::HealingGoodie(double x, double y, StudentWorld* world)
    :Objects(IID_HEAL_GOODIE, SOUND_GOT_GOODIE, x, y, 0, 1.0, 250, world)
{}

//what happens when GhostRacer collected healinggoodie
void HealingGoodie::overlap()
{
    getWorld()->getRacer()->heal();
}

//is healinggoodie affected by water spray
bool HealingGoodie::isSprayed()
{
    return true;
}

//soulgoodie constructor
SoulGoodie::SoulGoodie(double x, double y, StudentWorld* world)
    :Objects(IID_SOUL_GOODIE, SOUND_GOT_SOUL, x, y, 0, 4.0, 100, world)
{}

//what happens when GhostRacer drives over soulgoodie
void SoulGoodie::overlap()
{
    getWorld()->addSoul();
}

//soulgoodie rotates
bool SoulGoodie::doesRotate()
{
    return true;
}


