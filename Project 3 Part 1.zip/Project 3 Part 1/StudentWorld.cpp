#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

int StudentWorld::init()
{
    m_gr = new GhostRacer(this);
    
    double LEFT_EDGE = ROAD_CENTER - ROAD_WIDTH / 2;
    double RIGHT_EDGE = ROAD_CENTER + ROAD_WIDTH / 2;
    int n = VIEW_HEIGHT / SPRITE_HEIGHT;
    
    for (int i = 0; i < n; i++)
    {
        m_actorlist.push_back(new BorderLine(this, LEFT_EDGE, i * SPRITE_HEIGHT, IID_YELLOW_BORDER_LINE));
    }
    
    for (int i = 0; i < n; i++)
    {
        m_actorlist.push_back(new BorderLine(this, RIGHT_EDGE, i * SPRITE_HEIGHT, IID_YELLOW_BORDER_LINE));
    }
    
    int m = VIEW_HEIGHT / (4 * SPRITE_HEIGHT);
    
    for (int i = 0; i < m; i++)
    {
        m_actorlist.push_front(new BorderLine(this, LEFT_EDGE + ROAD_WIDTH / 3, i * (4 * SPRITE_HEIGHT), IID_WHITE_BORDER_LINE));
    }
    
    for (int i = 0; i < m; i++)
    {
        m_actorlist.push_front(new BorderLine(this, RIGHT_EDGE - ROAD_WIDTH / 3, i * (4 * SPRITE_HEIGHT), IID_WHITE_BORDER_LINE));
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    m_gr->doSomething();
    list<Actor*>::iterator it;
    it = m_actorlist.begin();
    while (it != m_actorlist.end())
    {
        if ((*it)->alive())
            (*it)->doSomething();
        if (!m_gr->alive())
        {
            decLives();
            return GWSTATUS_PLAYER_DIED;
        }
        it++;
    }

    list<Actor*>::iterator it2;
    it2 = m_actorlist.begin();

    while (it2 != m_actorlist.end())
    {
        if (!((*it2)->alive()))
        {
            delete(*it2);
            it2 = m_actorlist.erase(it2);
        }
        else
        {
            it2++;
        }
    }

    double newBorderY = VIEW_HEIGHT - SPRITE_HEIGHT;
    Actor* a = m_actorlist.front();
    double deltaY = newBorderY - a->getY();
    if (deltaY >= SPRITE_HEIGHT)
    {
        m_actorlist.push_back(new BorderLine(this, ROAD_CENTER - ROAD_WIDTH / 2, newBorderY, IID_YELLOW_BORDER_LINE));
        m_actorlist.push_back(new BorderLine(this, ROAD_CENTER + ROAD_WIDTH / 2, newBorderY, IID_YELLOW_BORDER_LINE));
    }

    if (deltaY >= SPRITE_HEIGHT * 4)
    {
        m_actorlist.push_front(new BorderLine(this, ROAD_CENTER - ROAD_WIDTH / 2 + ROAD_WIDTH / 3, newBorderY, IID_WHITE_BORDER_LINE));
        m_actorlist.push_front(new BorderLine(this, ROAD_CENTER + ROAD_WIDTH / 2 - ROAD_WIDTH / 3, newBorderY, IID_WHITE_BORDER_LINE));
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete m_gr;
}

GhostRacer* StudentWorld::getRacer()
{
    return m_gr;
}

void killActor(Actor* act)
{
    delete act;
}

//add other actors to back!
