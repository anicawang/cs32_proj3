#include "Actor.h"
#include "StudentWorld.h"
#include <cmath>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

//ACTOR
Actor::Actor(int imageID, int startX, int startY, int startDirection, double size, int depth, int health, int speed, StudentWorld* world)
:GraphObject(imageID, startX, startY, startDirection, size, depth), m_avoid(true), m_world(world), m_health(health), m_speed(speed)
{}

Actor::~Actor()
{}

//change isalive
bool Actor::alive()
{
    return (m_health > 0);
}

bool Actor::avoid()
{
    return m_avoid;
}

void Actor::noAvoid()
{
    m_avoid = false;
}

void Actor::damage(int health)
{
    m_health -= health;
}

int Actor::getSpeed()
{
    return m_speed;
}

int Actor::setSpeed(int s)
{
    m_speed += s;
    return m_speed;
}

StudentWorld* Actor::getWorld()
{
    return m_world;
}

GhostRacer::GhostRacer(StudentWorld* world)
:Actor(IID_GHOST_RACER, 128, 32, 90, 4, 0, 100, 0, world), m_spray(10)
{}

void GhostRacer::doSomething()
{
    int left = ROAD_CENTER - ROAD_WIDTH / 2;
    int right = ROAD_CENTER + ROAD_WIDTH / 2;
    if (!alive())
        return;
    if (getX() <= left)
    {
        if (getDirection() > 90)
        {
            damage(10);
        }
        setDirection(82);
        getWorld()->playSound(SOUND_VEHICLE_CRASH);
    }
    else if (getX() >= right)
    {
        if (getDirection() < 90)
        {
            damage(10);
        }
        setDirection(98);
        getWorld()->playSound(SOUND_VEHICLE_CRASH);
    }
    int ch;
    if (getWorld()->getKey(ch))
    {
        switch (ch)
        {
            case KEY_PRESS_LEFT:
                if (getDirection()<114)
                    setDirection(getDirection()+8);
                break;
            case KEY_PRESS_RIGHT:
                if (getDirection()>66)
                    setDirection(getDirection()-8);
                break;
            case KEY_PRESS_SPACE:
                if (m_spray >= 1)
                    m_spray--;
                break;
            case KEY_PRESS_UP:
                if (getSpeed() < 5)
                    setSpeed(1);
                break;
            case KEY_PRESS_DOWN:
                if (getSpeed() > -1)
                    setSpeed(-1);
                break;
        }
    }
    double pi = 2 * asin(1.0);
    int direction = getDirection();
    double max_shift_per_tick = 4.0;
    double delta_x = cos(direction * (pi / 180)) * max_shift_per_tick;
    double cur_x = getX();
    double cur_y = getY();
    moveTo(cur_x + delta_x, cur_y);
}

BorderLine::BorderLine(StudentWorld* world, int x, int y, int imageID)
:Actor(imageID, x, y, 0, 2.0, 2, 1, -4, world)
{}

void BorderLine::doSomething()
{
    double pi = 2 * asin (1.0);
    
    GhostRacer* racer = getWorld()->getRacer();
    double verticalSpeed = racer->getSpeed() * sin(racer->getDirection() * (pi / 180));
    double yspeed = getSpeed() - verticalSpeed;
    double xspeed = 0;
    double new_x = getX() + xspeed;
    double new_y = getY() + yspeed;
    
    moveTo(new_x, new_y);
    
    if (getX() < 0 || getY() < 0 || getX() > VIEW_WIDTH || getY() > VIEW_WIDTH)
    {
        damage(1);
        return;
    }
}
