#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
    Actor(int imageID, int startX, int startY, int startDirection, double size, int depth, int health, int speed, StudentWorld* world);
    virtual ~Actor();
    virtual void doSomething() = 0;
    virtual bool alive();
    virtual bool avoid();
    virtual void noAvoid();
    virtual void damage(int health);
    int getSpeed();
    int setSpeed(int s);
    StudentWorld* getWorld();

private:
    int m_health;
    bool m_avoid;
    int m_speed;
    StudentWorld* m_world;
};

class GhostRacer : public Actor
{
public:
    GhostRacer(StudentWorld* world);
    void doSomething();
    
private:
    int m_health;
    int m_spray;
};

class BorderLine : public Actor
{
public:
    BorderLine(StudentWorld* world, int x, int y, int imageID);
    void doSomething();
    
};

class ZombiePedestrian : public Actor
{
//public:
//    ZombiePedestrian();
//    ~ZombiePedestrian();
//private:
};

class HumanPedestrian : public Actor
{
//public:
//    HumanPedestrian();
//    ~HumanPedestrian();
//private:
};

class ZombieCabs : public Actor
{
//public:
//    ZombieCabs();
//    ~ZombieCabs();
//private:
};


#endif // ACTOR_H_
